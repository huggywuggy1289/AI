package com.example.sdukdy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class StudytimeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_studytime)
    }
}